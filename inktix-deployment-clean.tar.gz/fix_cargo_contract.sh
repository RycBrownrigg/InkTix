#!/bin/bash

# Quick fix for cargo-contract installation issue
# Run this if the main deployment script fails on cargo-contract

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

log "Fixing cargo-contract installation..."

# Source cargo environment
source ~/.cargo/env

# Try different installation methods
log "Attempting to install cargo-contract..."

# Method 1: Try stable version
if cargo install --locked cargo-contract; then
    success "cargo-contract installed (stable version)"
elif cargo install cargo-contract; then
    success "cargo-contract installed (without --locked)"
else
    warning "Standard installation failed, trying alternative method..."
    
    # Method 2: Try installing from git
    if cargo install --git https://github.com/paritytech/cargo-contract cargo-contract; then
        success "cargo-contract installed from git"
    else
        # Method 3: Try with specific version
        warning "Git installation failed, trying with specific version..."
        if cargo install --version 3.2.0 cargo-contract; then
            success "cargo-contract installed (version 3.2.0)"
        else
            error "All cargo-contract installation methods failed"
        fi
    fi
fi

# Verify installation
if command -v cargo-contract &> /dev/null; then
    success "cargo-contract is now available: $(cargo contract --version)"
    log "You can now continue with the deployment by running: ./deploy.sh deploy"
else
    error "cargo-contract installation verification failed"
fi
